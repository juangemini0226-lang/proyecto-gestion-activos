# activos/urls.py
from django.urls import path
from . import views

app_name = "activos"   # <<--- AÑADIR ESTO

urlpatterns = [
    # Supervisor
    path('agendar/', views.agendar_mantenimiento, name='agendar_mantenimiento'),
    path('ordenes/', views.ordenes_list, name='ordenes_list'),
    path('ordenes/<int:pk>/asignar/', views.asignar_ot, name='asignar_ot'),
    path('ordenes/<int:pk>/estado/', views.cambiar_estado_ot, name='cambiar_estado_ot'),
    path('alerta/<int:pk>/crear-ot/', views.crear_ot_desde_alerta, name='crear_ot_desde_alerta'),

    # Operario
    path('tareas/', views.mis_tareas, name='mis_tareas'),

    # Existentes
    path('buscar/<str:codigo>/', views.detalle_activo_por_codigo, name='detalle_activo'),
    path('<int:activo_id>/iniciar-mantenimiento/', views.iniciar_mantenimiento, name='iniciar_mantenimiento'),
    path('mantenimiento/<int:registro_id>/', views.checklist_mantenimiento, name='checklist_mantenimiento'),
]
