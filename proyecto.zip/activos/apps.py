from django.apps import AppConfig


#class ActivosConfig(AppConfig):
 #   default_auto_field = 'django.db.models.BigAutoField'
  #  name = 'activos'


class ActivosConfig(AppConfig):
    name = "activos"
    def ready(self):
        import activos.signals  # noqa
