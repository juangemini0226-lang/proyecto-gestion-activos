# activos/signals.py
from datetime import date
from decimal import Decimal

from django.db.models.signals import pre_save, post_save
from django.dispatch import receiver

from activos.models import RegistroMantenimiento
from horometro.models import LecturaHorometro


@receiver(pre_save, sender=RegistroMantenimiento)
def _cache_old_estado(sender, instance: RegistroMantenimiento, **kwargs):
    """Guarda el estado anterior para detectar el cambio a 'CER'."""
    if instance.pk:
        instance._old_estado = (
            sender.objects.filter(pk=instance.pk)
            .values_list("estado", flat=True)
            .first()
        )


def _iso_year_week(d: date):
    iso = d.isocalendar()
    year = getattr(iso, "year", iso[0])
    week = getattr(iso, "week", iso[1])
    return int(year), int(week)


@receiver(post_save, sender=RegistroMantenimiento)
def _apply_preventivo_on_close(sender, instance: RegistroMantenimiento, created, **kwargs):
    """
    Si la OT cambia a CERRADA y es PREVENTIVA:
      - Actualiza la lectura (año/semana) con:
          ciclo_ultimo_preventivo = lectura de ejecución (o la de la lectura encontrada)
          ciclos_desde_ultimo_preventivo = 0
      - No cierra alertas (queda manual para el supervisor).
    """
    if created:
        return

    old = getattr(instance, "_old_estado", None)
    if old == instance.estado:
        return

    if instance.estado != "CER" or instance.tipo != "PRE":
        return

    # Determinar año/semana de ejecución
    if instance.anio_ejecucion and instance.semana_ejecucion:
        y, w = instance.anio_ejecucion, instance.semana_ejecucion
    else:
        y, w = _iso_year_week((instance.fecha_cierre or date.today()))

    # Buscar la lectura de esa semana; si no hay, usar la última del activo
    lh = (
        LecturaHorometro.objects
        .filter(activo=instance.activo, anio=y, semana=w)
        .order_by("anio", "semana")
        .last()
    ) or (
        LecturaHorometro.objects
        .filter(activo=instance.activo)
        .order_by("anio", "semana")
        .last()
    )

    if not lh:
        # No hay lecturas aún; no podemos fijar baseline
        return

    lectura = instance.lectura_ejecucion or lh.lectura or lh.ciclos_oracle
    if lectura is None:
        return

    lh.ciclo_ultimo_preventivo = lectura
    lh.ciclos_desde_ultimo_preventivo = Decimal("0")
    lh.save(update_fields=["ciclo_ultimo_preventivo", "ciclos_desde_ultimo_preventivo"])
