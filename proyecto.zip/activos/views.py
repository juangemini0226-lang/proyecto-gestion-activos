# activos/views.py
from datetime import datetime

from django import forms
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .models import (
    Activo,
    RegistroMantenimiento,
    TareaMantenimiento,
    DetalleMantenimiento,
)
from horometro.models import AlertaMantenimiento, LecturaHorometro


# ===================== Helpers de permisos =====================
def es_supervisor(u):
    return u.is_superuser or u.groups.filter(name__iexact="Supervisor").exists()


def operarios_qs():
    return (
        User.objects.filter(is_active=True, groups__name__iexact="Operarios")
        .order_by("username")
    )


# ===================== Formularios =====================
class AsignarOTForm(forms.Form):
    operario = forms.ModelChoiceField(
        queryset=User.objects.none(),  # se carga en __init__
        required=True,
        label="Asignar a",
        help_text="Selecciona un operario.",
    )
    comentario = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={"rows": 2}),
        label="Comentario (opcional)",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["operario"].queryset = operarios_qs()


class AgendarOTForm(forms.Form):
    activo = forms.ModelChoiceField(queryset=Activo.objects.none(), label="Activo")
    tipo = forms.ChoiceField(choices=RegistroMantenimiento.TIPOS, initial="PRE", label="Tipo")
    asignado_a = forms.ModelChoiceField(
        queryset=User.objects.none(), required=False, label="Asignado a"
    )
    notas = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={"rows": 2}),
        label="Notas",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["activo"].queryset = Activo.objects.order_by("codigo")
        self.fields["asignado_a"].queryset = operarios_qs()


# ===================== Vistas existentes (básicas) =====================
@login_required
def detalle_activo_por_codigo(request, codigo: str):
    activo = get_object_or_404(Activo, codigo__iexact=codigo)
    lecturas = (
        LecturaHorometro.objects.filter(activo=activo)
        .order_by("-anio", "-semana")[:12]
    )
    return render(
        request, "activos/detalle_activo.html", {"activo": activo, "lecturas": lecturas}
    )


@login_required
def iniciar_mantenimiento(request, activo_id: int):
    activo = get_object_or_404(Activo, pk=activo_id)
    ot = RegistroMantenimiento.objects.create(
        activo=activo,
        estado="PRO",
        tipo="PRE",
        fecha_inicio_ejecucion=timezone.now(),
        creado_por=request.user,
        asignado_a=request.user
        if request.user.groups.filter(name__iexact="Operarios").exists()
        else None,
    )
    messages.success(request, f"Orden iniciada para {activo.codigo}.")
    return redirect("activos:checklist_mantenimiento", registro_id=ot.id)


@login_required
def checklist_mantenimiento(request, registro_id: int):
    ot = get_object_or_404(RegistroMantenimiento, pk=registro_id)
    tareas = DetalleMantenimiento.objects.filter(registro=ot).select_related("tarea")

    if request.method == "POST":
        for det in tareas:
            det.completado = bool(request.POST.get(f"tarea_{det.id}"))
            det.observaciones = request.POST.get(f"obs_{det.id}", "").strip() or None
            det.save(update_fields=["completado", "observaciones"])
        messages.success(request, "Checklist actualizado.")
        return redirect("activos:checklist_mantenimiento", registro_id=registro_id)

    return render(request, "activos/checklist_mantenimiento.html", {"ot": ot, "tareas": tareas})


@login_required
@user_passes_test(es_supervisor)
def agendar_mantenimiento(request):
    if request.method == "POST":
        form = AgendarOTForm(request.POST)
        if form.is_valid():
            ot = RegistroMantenimiento.objects.create(
                activo=form.cleaned_data["activo"],
                tipo=form.cleaned_data["tipo"],
                estado="PEN",
                creado_por=request.user,
                asignado_a=form.cleaned_data.get("asignado_a") or None,
            )
            # Checklist base con todas las tareas maestras (si las usas)
            for tarea in TareaMantenimiento.objects.all():
                DetalleMantenimiento.objects.create(registro=ot, tarea=tarea)

            messages.success(request, f"Orden creada (#{ot.id}).")
            return redirect("activos:ordenes_list")
    else:
        form = AgendarOTForm()

    return render(request, "activos/agendar_mantenimiento.html", {"form": form})


# ===================== NUEVAS: Gestión de OT =====================
@login_required
@user_passes_test(es_supervisor)
def ordenes_list(request):
    """Listado de órdenes para supervisores con filtros básicos."""
    estado = (request.GET.get("estado") or "").strip().upper()
    tipo = (request.GET.get("tipo") or "").strip().upper()
    q = (request.GET.get("q") or "").strip()

    qs = (
        RegistroMantenimiento.objects.select_related(
            "activo", "asignado_a", "creado_por", "completado_por"
        )
        .order_by("-fecha_creacion")
    )
    if estado:
        qs = qs.filter(estado=estado)
    if tipo:
        qs = qs.filter(tipo=tipo)
    if q:
        qs = qs.filter(
            Q(activo__codigo__icontains=q)
            | Q(activo__nombre__icontains=q)
            | Q(asignado_a__username__icontains=q)
        )

    return render(
        request,
        "activos/ordenes_list.html",
        {"ordenes": qs, "estado": estado, "tipo": tipo, "q": q},
    )


@login_required
def mis_tareas(request):
    """Vista para operarios: muestra tareas asignadas en PENDIENTE / PRO."""
    qs = (
        RegistroMantenimiento.objects.filter(
            asignado_a=request.user, estado__in=["PEN", "PRO"]
        )
        .select_related("activo")
        .order_by("fecha_creacion")
    )
    return render(request, "activos/mis_tareas.html", {"ordenes": qs})


@login_required
@user_passes_test(es_supervisor)
def crear_ot_desde_alerta(request, pk: int):
    """
    Crea una OT preventiva a partir de una alerta.
    No se cierra la alerta automáticamente; se marca EN_PROCESO.
    """
    alerta = get_object_or_404(AlertaMantenimiento, pk=pk)
    ot = RegistroMantenimiento.objects.create(
        activo=alerta.activo,
        tipo="PRE",
        estado="PEN",
        creado_por=request.user,
    )
    for tarea in TareaMantenimiento.objects.all():
        DetalleMantenimiento.objects.create(registro=ot, tarea=tarea)

    if alerta.estado != "CERRADA":
        alerta.estado = "EN_PROCESO"
        alerta.save(update_fields=["estado", "actualizado_en"])

    messages.success(
        request, f"Orden #{ot.id} creada para {alerta.activo.codigo}. La alerta quedó EN_PROCESO."
    )
    return redirect("activos:ordenes_list")


@login_required
@user_passes_test(es_supervisor)
def asignar_ot(request, pk: int):
    """Asigna o reasigna una OT a un operario."""
    ot = get_object_or_404(
        RegistroMantenimiento.objects.select_related("activo"), pk=pk
    )

    if request.method == "POST":
        form = AsignarOTForm(request.POST)
        if form.is_valid():
            ot.asignado_a = form.cleaned_data["operario"]
            ot.save(update_fields=["asignado_a"])
            messages.success(
                request, f"OT #{ot.id} asignada a {ot.asignado_a.username}."
            )
            return redirect("activos:ordenes_list")
    else:
        form = AsignarOTForm(initial={"operario": ot.asignado_a_id})

    return render(request, "activos/ot_asignar.html", {"ot": ot, "form": form})


@login_required
@user_passes_test(es_supervisor)
def cambiar_estado_ot(request, pk: int):
    """
    Cambia el estado de una OT. Se espera un POST con 'estado'
    (PEN, PRO, REV o COM).
    """
    ot = get_object_or_404(RegistroMantenimiento, pk=pk)

    if request.method != "POST":
        messages.error(request, "Método no permitido.")
        return redirect("activos:ordenes_list")

    nuevo = (request.POST.get("estado") or "").upper()
    validos = {c[0] for c in RegistroMantenimiento.ESTADOS}
    if nuevo not in validos:
        messages.error(request, "Estado inválido.")
        return redirect("activos:ordenes_list")

    # Actualiza timestamps cuando aplica
    if nuevo == "PRO" and ot.fecha_inicio_ejecucion is None:
        ot.fecha_inicio_ejecucion = timezone.now()
    if nuevo == "COM":
        ot.fecha_fin_ejecucion = timezone.now()

    ot.estado = nuevo
    ot.save(update_fields=["estado", "fecha_inicio_ejecucion", "fecha_fin_ejecucion"])
    messages.success(request, f"OT #{ot.id} ahora está en '{ot.get_estado_display()}'.")
    return redirect("activos:ordenes_list")
