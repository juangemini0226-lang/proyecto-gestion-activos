# activos/forms.py
from django import forms
import datetime

class ExcelUploadForm(forms.Form):
    semana = forms.ChoiceField(label="Selecciona la Semana del Informe")
    archivo_excel = forms.FileField(label="Selecciona el archivo Excel de Odómetro")

    def __init__(self, *args, **kwargs):
        # Sacamos las semanas ya usadas que nos pasará la vista
        semanas_usadas = kwargs.pop('semanas_usadas', [])
        super().__init__(*args, **kwargs)
        
        # Creamos las opciones para las 52 semanas del año
        opciones_semana = [(i, f"Semana {i}") for i in range(1, 53)]
        
        # Filtramos las opciones para quitar las semanas que ya tienen datos
        opciones_disponibles = [opcion for opcion in opciones_semana if opcion[0] not in semanas_usadas]
        
        # Asignamos las opciones disponibles a nuestro campo
        self.fields['semana'].choices = opciones_disponibles