from django.db import models
from django.contrib.auth.models import User


# -------- Tarea maestra --------
class TareaMantenimiento(models.Model):
    nombre = models.CharField(max_length=255, verbose_name="Nombre de la Tarea")
    descripcion = models.TextField(blank=True, help_text="Instrucciones detalladas de la tarea.")

    def __str__(self):
        return self.nombre


# -------- Activo --------
class Activo(models.Model):
    codigo = models.CharField(max_length=100, unique=True, verbose_name="Código")
    numero_activo = models.CharField(max_length=255, verbose_name="# Activo")
    nombre = models.CharField(max_length=255, verbose_name="Nombre")
    peso = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="Peso")

    def __str__(self):
        return f"{self.codigo} - {self.nombre}"


# -------- Registro de mantenimiento (UNIFICADO) --------
class RegistroMantenimiento(models.Model):
    ESTADOS = [
        ("PEN", "Pendiente"),
        ("PRO", "En Progreso"),
        ("REV", "Pendiente Revisión"),
        ("CER", "Cerrada"),  # <- estado de cierre usado por las señales
    ]
    TIPOS = [
        ("PRE", "Preventivo"),
        ("COR", "Correctivo"),
    ]

    activo = models.ForeignKey(Activo, on_delete=models.CASCADE, related_name="mantenimientos")
    estado = models.CharField(max_length=3, choices=ESTADOS, default="PEN")
    tipo = models.CharField(max_length=3, choices=TIPOS, default="PRE")

    # Fechas del ciclo de vida
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    fecha_inicio_ejecucion = models.DateTimeField(null=True, blank=True)
    fecha_fin_ejecucion = models.DateTimeField(null=True, blank=True)

    # Cierre (usado por señales para fijar baseline en horómetro)
    fecha_cierre = models.DateTimeField(null=True, blank=True)
    anio_ejecucion = models.PositiveSmallIntegerField(null=True, blank=True)
    semana_ejecucion = models.PositiveSmallIntegerField(null=True, blank=True)
    lectura_ejecucion = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)

    # Usuarios
    creado_por = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="ordenes_creadas")
    asignado_a = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="tareas_asignadas")
    completado_por = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="tareas_completadas")

    def __str__(self):
        return f"{self.get_tipo_display()} de {self.activo.nombre} - {self.get_estado_display()}"


# -------- Detalle de mantenimiento --------
class DetalleMantenimiento(models.Model):
    registro = models.ForeignKey(RegistroMantenimiento, on_delete=models.CASCADE)
    tarea = models.ForeignKey(TareaMantenimiento, on_delete=models.CASCADE)
    completado = models.BooleanField(default=False)
    observaciones = models.TextField(blank=True, null=True, verbose_name="Observaciones")

    def __str__(self):
        return f"Tarea '{self.tarea.nombre}' para registro {self.registro.id}"


# -------- Historial de ciclos (si lo sigues usando) --------
class RegistroCiclosSemanal(models.Model):
    activo = models.ForeignKey(Activo, on_delete=models.CASCADE, related_name="historial_ciclos")
    año = models.PositiveIntegerField()
    semana = models.PositiveIntegerField()
    ciclos = models.PositiveIntegerField(default=0)
    fecha_carga = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.activo.codigo} - Año {self.año}, Semana {self.semana}: {self.ciclos} ciclos"
