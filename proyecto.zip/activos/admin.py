import pandas as pd
import datetime
from django.contrib import admin, messages
from django.shortcuts import render, redirect
from django.urls import path
from .models import Activo, TareaMantenimiento, RegistroMantenimiento, DetalleMantenimiento, RegistroCiclosSemanal
from .forms import ExcelUploadForm
from import_export import resources
from import_export.admin import ImportExportModelAdmin

# --- Resource para la importación inicial de Activos ---
class ActivoResource(resources.ModelResource):
    class Meta:
        model = Activo

# --- Admin para el modelo Activo ---
@admin.register(Activo)
class ActivoAdmin(ImportExportModelAdmin):
    resource_class = ActivoResource
    list_display = ('codigo', 'numero_activo', 'nombre', 'peso')
    search_fields = ('codigo', 'nombre')

# --- Admin para Tareas ---
@admin.register(TareaMantenimiento)
class TareaMantenimientoAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'descripcion')
    search_fields = ('nombre',)

# --- Admin para Registros de Mantenimiento ---
@admin.register(RegistroMantenimiento)
class RegistroMantenimientoAdmin(admin.ModelAdmin):
    list_display = ('activo', 'estado', 'tipo', 'asignado_a', 'fecha_creacion')
    list_filter = ('estado', 'tipo')

# --- Admin para Historial de Ciclos con la Lógica de Carga de Excel ---
@admin.register(RegistroCiclosSemanal)
class RegistroCiclosSemanalAdmin(admin.ModelAdmin):
    list_display = ('activo', 'año', 'semana', 'ciclos', 'fecha_carga')
    list_filter = ('año', 'semana', 'activo')

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('upload-excel/', self.upload_excel_view, name='upload_excel'),
        ]
        return custom_urls + urls

    def upload_excel_view(self, request):
        año_actual = datetime.date.today().year
        semanas_con_datos = RegistroCiclosSemanal.objects.filter(año=año_actual).values_list('semana', flat=True)
        
        if request.method == 'POST':
            form = ExcelUploadForm(request.POST, request.FILES, semanas_usadas=semanas_con_datos)
            if form.is_valid():
                excel_file = request.FILES['archivo_excel']
                semana_seleccionada = int(form.cleaned_data['semana'])
                
                try:
                    df = pd.read_excel(excel_file, sheet_name='Odometro', header=4, engine='openpyxl')
                    
                    df = df[~df['NUMERO ACTIVO'].astype(str).str.contains('El Activo de EAM', na=False)]
                    df_moldes = df[df['TIPO ACTIVO'] == 'MOLD'].copy()

                    if df_moldes.empty:
                        messages.warning(request, "No se encontraron registros de tipo 'MOLD' en el archivo.")
                        return redirect("..")

                    for _, row in df_moldes.iterrows():
                        try:
                            activo_obj = Activo.objects.get(codigo=row['NUMERO ACTIVO'])
                            RegistroCiclosSemanal.objects.update_or_create(
                                activo=activo_obj,
                                año=año_actual,
                                semana=semana_seleccionada,
                                defaults={'ciclos': row['MEDIDOR']}
                            )
                        except Activo.DoesNotExist:
                            messages.warning(request, f"Activo {row['NUMERO ACTIVO']} no encontrado. Se omitió.")
                    
                    messages.success(request, f"Archivo de la semana {semana_seleccionada} procesado con éxito.")
                    return redirect("..")

                except KeyError as e:
                    messages.error(request, f"Error de columna: No se encontró la columna {e}. Revisa el nombre en el Excel.")
                    return redirect("..")
                except Exception as e:
                    messages.error(request, f"Ocurrió un error inesperado: {e}")
                
        else:
            form = ExcelUploadForm(semanas_usadas=semanas_con_datos)

        return render(
            request, 
            "admin/carga_odometro.html", 
            {"form": form, "title": "Cargar Odómetro"}
        )

# Registra el último modelo para que sea visible en el admin
admin.site.register(DetalleMantenimiento)